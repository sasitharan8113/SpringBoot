package demo.bootproject.fileDownload.documentConvert;

import java.awt.Color;
import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import demo.bootproject.fileDownload.Entity.FileEntity;
import jakarta.servlet.http.HttpServletResponse;


public class UserPDFExporter {
    private List<FileEntity> listUsers;

    public UserPDFExporter(List<FileEntity> listUsers) {
        this.listUsers = listUsers;
    }

    private void writeTableHeader(PdfPTable table) {
        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(Color.WHITE);
        cell.setPadding(8);

        Font font = FontFactory.getFont(FontFactory.HELVETICA);
        font.setColor(Color.BLACK);

        cell.setPhrase(new Phrase("id", font));

        table.addCell(cell);

        cell.setPhrase(new Phrase("regNo", font));
        table.addCell(cell);

        cell.setPhrase(new Phrase("name", font));
        table.addCell(cell);

        cell.setPhrase(new Phrase("dob", font));
        table.addCell(cell);

        cell.setPhrase(new Phrase("mark", font));
        table.addCell(cell);

        cell.setPhrase(new Phrase("status", font));
        table.addCell(cell);

        cell.setPhrase(new Phrase("emailId", font));
        table.addCell(cell);

        cell.setPhrase(new Phrase("address", font));
        table.addCell(cell);
    }

    private void writeTableData(PdfPTable table) {
        for (FileEntity user : listUsers) {

            table.addCell(String.valueOf(user.getId()));

            table.addCell(String.valueOf(user.getRegNo()));

            table.addCell(user.getName());

            table.addCell(String.valueOf(user.getDob()));

            table.addCell(String.valueOf(user.getMark()));

            table.addCell(String.valueOf(user.getStatus()));

            table.addCell(user.getEmailId());

            table.addCell(user.getAddress());
        }
    }

    public void export(HttpServletResponse response) throws DocumentException, FileNotFoundException {
        Document document = new Document(PageSize.A4);
        DateFormat dateFormatter = new SimpleDateFormat("yyyyMMddHHmmss");
        String currentDateTime = dateFormatter.format(new Date());
        String path="D:\\Java\\Document";
        File newDirectory = new File(path, "pdf");
        newDirectory.mkdir();
        String pathPdf ="D:\\Java\\Document\\pdf\\"+currentDateTime+".pdf";
        PdfWriter.getInstance(document, new FileOutputStream(pathPdf));
        document.open();
        Font font = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
        font.setSize(8);
        font.setColor(Color.WHITE);

        Paragraph p = new Paragraph("List of Users", font);
        p.setAlignment(Paragraph.ALIGN_CENTER);

        document.add(p);

        PdfPTable table = new PdfPTable(8);
        table.setWidthPercentage(100f);
        table.setWidths(new float[] {1.5f, 2f, 2f, 3.5f, 1.5f,1.5f,4f,3f});
        table.setSpacingBefore(10);
        writeTableHeader(table);
        writeTableData(table);
        document.add(table);

        document.close();

    }

}