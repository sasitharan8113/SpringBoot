package demo.bootproject.fileDownload.Entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
@Entity
@Table(name="fileTable")
public class FileEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Digits(integer = 10, fraction = 0,message = "limit is 10 digit only")
    private Long regNo;

    @Size(min=1,max=6,message="name limit is 1 to 6")
    @NotEmpty(message ="name is empty.")
    @NotBlank(message = "name is blank")
    private String name;

    @JsonFormat(pattern = "dd-mm-yyyy")
    private Date dob;

    @Min(value = 1)
    @Max(value = 100,message = "Mark limit is over")
    private Double mark;

    @AssertTrue(message = "status is true only")
    private Boolean status;

    @Email(message = "invalid email input.")
    @NotEmpty(message = "Email id is empty.")
    @NotBlank(message = "Email Id is blank")
    private String emailId;

    @Size(min=5,max=50,message = "Address Limit is 5 to 50 character.")
    @NotEmpty(message = "Address details is empty.")
    @NotBlank(message = "Address is blank")
    private String address;

}
