package demo.bootproject.fileDownload.repo;

import demo.bootproject.fileDownload.Entity.FileEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface FileRepo extends JpaRepository<FileEntity,Integer> {

    @Query(value="select * from file_table",nativeQuery = true)
    List<FileEntity>findAllFile();
    @Query(value="select t from FileEntity t order by t.regNo")
    List<FileEntity> findSpecific();
}
