package demo.bootproject.fileDownload.controller;

import com.lowagie.text.DocumentException;
import demo.bootproject.fileDownload.Entity.FileEntity;
import demo.bootproject.fileDownload.documentConvert.UserCSVExporter;
import demo.bootproject.fileDownload.documentConvert.UserPDFExporter;
import demo.bootproject.fileDownload.documentConvert.UserXlsExporter;
import demo.bootproject.fileDownload.documentConvert.UserXslxExporter;
import demo.bootproject.fileDownload.services.FileService;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import net.minidev.json.JSONObject;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/filePost")
public class FileController {

    @Autowired
    FileService myMethod;


    //Post Method=http://localhost:8080/filePost/file
    @PostMapping("/file")
    public FileEntity details(@Valid @RequestBody FileEntity myValue){
        return myMethod.insertValue(myValue);
    }


    //Get Method=http://localhost:8080/filePost/getFile
    @GetMapping("getFile")
    public List<FileEntity> allFileDetails() {
        return myMethod.allFile();
    }

    @GetMapping("/particularRegNo/{regNo}")
    public List<FileEntity> particularFile() {
        return myMethod.specificFile();
    }


    //Get Method=http://localhost:8080/filePost/choose?file=chooseFile
    @GetMapping("/choose")
    public ResponseEntity<?> download(@RequestParam("file") String file, HttpServletResponse response) throws IOException
    {
        if (file.equalsIgnoreCase("pdf")) {
            List<FileEntity> listUsers = myMethod.allFile1();
            UserPDFExporter exporter = new UserPDFExporter(listUsers);
            exporter.export(response);
            JSONObject obj1=new JSONObject();
            obj1.put("Message","PDF convert is completed.");
            return new ResponseEntity<>(obj1, HttpStatus.OK);

        }
        else if (file.equalsIgnoreCase("csv"))
        {
            List<FileEntity> listUsers = myMethod.allFile1();
            UserCSVExporter conversion = new UserCSVExporter(listUsers);
            conversion.exportToCSV(response);
            JSONObject obj = new JSONObject();
            obj.put("Status", "Successfully downloaded the CSV file");
            return new ResponseEntity(obj, HttpStatus.OK);

        }
        else if (file.equalsIgnoreCase("xlsx"))
        {
            List<FileEntity> studentList = myMethod.allFile1();
            UserXslxExporter generator = new UserXslxExporter(studentList);
            generator.generateExcelFile(response);
            JSONObject obj = new JSONObject();
            obj.put("Status", "Successfully downloaded the XLSX file");
            return new ResponseEntity(obj, HttpStatus.OK);
        }
        else if (file.equalsIgnoreCase("xls"))
        {
            List<FileEntity> studentList = myMethod.allFile1();
            UserXlsExporter generator = new UserXlsExporter(studentList);
            generator.generateXls(response);
            JSONObject obj = new JSONObject();
            obj.put("Status", "Successfully downloaded the XLS file");
            return new ResponseEntity(obj, HttpStatus.OK);
        }
        else
        {
            JSONObject obj = new JSONObject();
            obj.put("Status", "File type doesn't match");
            return new ResponseEntity(obj, HttpStatus.OK);
        }
    }

}
