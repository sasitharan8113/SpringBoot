package demo.bootproject.fileDownload.services;

import demo.bootproject.fileDownload.Entity.FileEntity;
import demo.bootproject.fileDownload.repo.FileRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;


@Service
public class FileService {
    @Autowired
    FileRepo data;

    public List<FileEntity>allFile(){
        return data.findAllFile();
    }
    public List<FileEntity>specificFile(){
        return data.findSpecific();
    }


    public FileEntity insertValue(@RequestBody FileEntity sampleEntity) {
            return this.data.save(sampleEntity);
    }


    public List<FileEntity> allFile1() {
        return data.findAll(Sort.by("emailId").ascending());
    }
}
