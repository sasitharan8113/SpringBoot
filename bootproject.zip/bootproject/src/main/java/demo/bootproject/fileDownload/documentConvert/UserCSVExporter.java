package demo.bootproject.fileDownload.documentConvert;

import demo.bootproject.fileDownload.Entity.FileEntity;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class UserCSVExporter
{
    private  Writer writer;
    private List<FileEntity> listUsers;

    public UserCSVExporter(List<FileEntity> listUsers) throws IOException {
        this.listUsers= listUsers;
        DateFormat dateFormatter = new SimpleDateFormat("ddMMyyyy_HHmmss");
        String currentDateTime = dateFormatter.format(new Date());
        String path = "D:\\Java\\Document";
        File newDirectory = new File(path, "csv");
        newDirectory.mkdir();
        String pathCsv ="D:\\Java\\Document\\csv\\"+currentDateTime+".csv";
        writer = new FileWriter(pathCsv);
    }
    public void exportToCSV(HttpServletResponse response)throws IOException
    {
        try(CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT)) {
            printer.printRecord("Id","RegNo","Name","Dob","Mark","Status","EmailId","Address");
            for (FileEntity student : listUsers)
            {
                printer.printRecord(student.getId(),student.getRegNo(), student.getName(),
                        student.getDob(),student.getMark(),student.getStatus(),
                        student.getEmailId(),student.getAddress());
            }
        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
