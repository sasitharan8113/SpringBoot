package demo.bootproject.ZipFile.Service;

import demo.bootproject.ZipFile.Entity.ZipEntity;
import jakarta.mail.internet.MimeMessage;
import net.minidev.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Service
public class ZipService {

    @Autowired
    JavaMailSender javaMailSender;

    @Autowired
    private Environment env;

    public ResponseEntity<?> sendZipFile(ZipEntity data)throws Exception {

        MimeMessage message = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);

        //Email From
        helper.setFrom(env.getProperty("username"));

        //Email To
        helper.setTo(data.getToEmail());

        //Mail Body
        helper.setText(data.getBody());

        //Mail subject
        helper.setSubject(data.getSubject());

        ZipOutputStream zos = null;
        try {
            String zipFilePath = "D:\\Java\\Document";
            FileOutputStream out = new FileOutputStream(zipFilePath);
            zos = new ZipOutputStream(out);
            File fileDownload = new File("D:\\Java\\Document\\csv");
            for (File file : fileDownload.listFiles()) {
                writeToZip(file, zos);
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        //Attachment
        FileSystemResource file = new FileSystemResource(new File("D:\\Java\\Document"));
        helper.addAttachment(file.getFilename(), file);

        javaMailSender.send(message);
        JSONObject obj = new JSONObject();
        obj.put("message", "Email sent is successfully");
        return new ResponseEntity<>(obj, HttpStatus.OK);
    }

    public void writeToZip(File file, ZipOutputStream zos)throws Exception{
        FileInputStream inStream=new FileInputStream(file);
        ZipEntry zipEntry=new ZipEntry(file.getAbsolutePath());
        zos.putNextEntry(zipEntry);
        byte[] bytes=new byte[1024];
        int length;
        while ((length=inStream.read(bytes))!=-1){
            zos.write(bytes,0,length);
        }
        zos.closeEntry();
        inStream.close();
    }
}
