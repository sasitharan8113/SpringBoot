package demo.bootproject.ZipFile.Entity;

import lombok.Data;

@Data
public class ZipEntity {

    private String toEmail;

    private String body;

    private String subject;

    private String attachment;
}
