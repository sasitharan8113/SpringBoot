package demo.bootproject.ZipFile.Controller;


import demo.bootproject.ZipFile.Entity.ZipEntity;
import demo.bootproject.ZipFile.Service.ZipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/zip")

public class ZipController {

    @Autowired
    ZipService service;

    @PostMapping("/sentMail")
    public ResponseEntity<?> zipEmail(@RequestBody ZipEntity data) throws Exception {
        return service.sendZipFile(data);
    }
}
