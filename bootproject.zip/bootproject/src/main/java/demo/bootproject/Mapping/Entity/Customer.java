package demo.bootproject.Mapping.Entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Data;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;

@Entity
@Data
@Table(name="customer")
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Min(value=1,message="Customer Id minimum limit is 1")
    @Max(value =9999,message = "Customer Id maximum limit is 9999")
    private Integer id;

    @Size(min=3,max=13,message="Customer Name limit is 3 to 13")
    @NotEmpty(message ="Customer Name is empty.")
    @NotBlank(message = "Customer Name is blank")
    private String customerName;

    @Size(min=3,max=13,message="gender limit is 3 to 13")
    @NotEmpty(message ="gender is empty.")
    @NotBlank(message = "gender is blank")
    private String gender;

    @OneToMany(cascade =CascadeType.ALL)
    @JoinColumn(name = "customer_name",referencedColumnName = "customerName")
    private List<Product>comments;

}
