package demo.bootproject.Mapping.Controller;

import demo.bootproject.Mapping.Entity.Book;
import demo.bootproject.Mapping.Entity.Customer;
import demo.bootproject.Mapping.Entity.EmployeeDetailsMapping;
import demo.bootproject.Mapping.Service.MappingService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/mapping")
public class MappingController {

    @Autowired
    MappingService service;


    @PostMapping("/oneToOne")
    public ResponseEntity<?>oneMapping(@Valid @RequestBody Book details) throws Exception {
        return service.join(details);
    }

    @GetMapping("/getOneToOne")
    public List<Book>getOneToOne(){
        return service.detailAll();
    }


    @PostMapping("/oneToMany")
    public ResponseEntity<?>mappingMany(@Valid @RequestBody Customer task)throws Exception{
        return service.joinMany(task);
    }

    @GetMapping("/getOneToMany")
    public List<Customer>getOneToMany(){
        return service.detailAllOne();
    }


    @PostMapping("/manyToMany")
    public ResponseEntity<?>manyMapping(@Valid @RequestBody EmployeeDetailsMapping demo)throws Exception{
        return service.joinAll(demo);
    }

    @GetMapping("/getManyToMany")
    public List<EmployeeDetailsMapping>getManyToMany(){
        return service.detailAllMany();
    }


}
