package demo.bootproject.Mapping.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

@Entity
@Data
@Table(name = "employeeMapping")
public class EmployeeDetailsMapping {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Min(value=1,message="Employee Id minimum limit is 1")
    @Max(value =9999,message = "Employee Id maximum limit is 9999")
    private Integer employeeId;

    @Size(min=3,max=13,message="employee name limit is 3 to 13")
    @NotEmpty(message ="employee name is empty.")
    @NotBlank(message = "employee name is blank")
    private String employeeName;

    @Size(min=3,max=13,message="employee role limit is 3 to 13")
    @NotEmpty(message ="employee role is empty.")
    @NotBlank(message = "employee role is blank")
    private String employeeRole;

    @ManyToMany(cascade =CascadeType.ALL)
    @JoinTable(name = "employees_projects",
            joinColumns = {
                    @JoinColumn(name = "employee_id")
            },
            inverseJoinColumns = {
                    @JoinColumn(name = "project_id")
            }
    )
    private Collection<ProjectDetailsMapping> projectMapping;
}
