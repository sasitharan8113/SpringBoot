package demo.bootproject.Mapping.Service;

import demo.bootproject.Mapping.Entity.Book;
import demo.bootproject.Mapping.Entity.Customer;
import demo.bootproject.Mapping.Entity.EmployeeDetailsMapping;
import demo.bootproject.Mapping.Entity.Story;
import demo.bootproject.Mapping.Repo.BookRepo;
import demo.bootproject.Mapping.Repo.CustomerRepo;
import demo.bootproject.Mapping.Repo.employeeRepo;
import net.minidev.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class MappingService{

    @Autowired
    BookRepo bookrepo;

    @Autowired
    employeeRepo detailExample;

    @Autowired
    CustomerRepo customerRepo;

    //Post Method Service-Book
    public ResponseEntity<?> join(Book details) throws Exception {
        Story story = details.getStory();
        story.setBook(details);
        bookrepo.save(details);
        JSONObject obj=new JSONObject();
        obj.put("message","One to One Mapping is completed.");
        return new ResponseEntity<>(obj, HttpStatus.OK);
    }

    //Get Method Service-Book
    public List<Book>detailAll(){
        return bookrepo.findAll();
    }

    //Post method service-Customer
    public ResponseEntity<?> joinMany(Customer task)throws Exception {
        customerRepo.save(task);
        JSONObject obj1=new JSONObject();
        obj1.put("message","One to Many Mapping is completed.");
        return new ResponseEntity<>(obj1, HttpStatus.OK);
    }

    //Get Method Service-Book
    public List<Customer>detailAllOne(){
        return customerRepo.findAll();
    }

    //Post method service-EmployeeDetailsMapping
    public ResponseEntity<?> joinAll(EmployeeDetailsMapping demo)throws Exception{
        detailExample.save(demo);
        JSONObject obj2=new JSONObject();
        obj2.put("message","Many to Many Mapping is completed.");
        return new ResponseEntity<>(obj2, HttpStatus.OK);
    }

    //Get Method Service-EmployeeDetailsMapping
    public List<EmployeeDetailsMapping>detailAllMany(){
        return detailExample.findAll();
    }
}
