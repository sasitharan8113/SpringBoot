package demo.bootproject.Mapping.Entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Data;

@Entity
@Data
@Table(name="product")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Min(value=1,message="Product Id minimum limit is 1")
    @Max(value =9999,message = "Product Id maximum limit is 9999")
    private Integer productId;

    @Size(min=3,max=13,message="Product Name limit is 3 to 13")
    @NotEmpty(message ="Product Name is empty.")
    @NotBlank(message = "Product Name is blank")
    private String productName;

    @Min(value=1,message="Project quantity minimum limit is 1")
    @Max(value =2000,message = "Project Id maximum limit is 2000")
    private Integer quantity;

}
