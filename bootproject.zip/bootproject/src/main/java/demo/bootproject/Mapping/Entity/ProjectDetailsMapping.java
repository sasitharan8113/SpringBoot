package demo.bootproject.Mapping.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

@Entity
@Data
@Table(name = "projectMapping")
public class ProjectDetailsMapping {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Min(value=1,message="Project Id minimum limit is 1")
    @Max(value =9999,message = "Project Id maximum limit is 9999")
    private Integer projectId;

    @Size(min=3,max=13,message="Project name limit is 3 to 13")
    @NotEmpty(message ="Project name is empty.")
    @NotBlank(message = "Project name is blank")
    private String projectName;
}
