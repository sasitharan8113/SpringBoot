package demo.bootproject.Mapping.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Data;

@Entity
@Data
@Table(name = "story")
public class Story {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Digits(integer = 10, fraction = 0,message = "Story Id Limit is 10 digit only")
    private Integer chapter;

    @Size(min=4,max=12,message="author name limit is 4 to 12")
    @NotEmpty(message ="author name is empty.")
    @NotBlank(message = "author name is blank")
    private String authorName;

    @Min(value = 100)
    @Max(value = 500,message = "Book price limit is 100 to 500 rupees only")
    private Integer price;

    @OneToOne(cascade = CascadeType.ALL)
    @JsonIgnore
    @JoinColumn(name = "user_name",referencedColumnName = "bookName")
    private Book book;
}
