package demo.bootproject.Mapping.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Entity
@Data
@Table(name = "book")
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Digits(integer = 10, fraction = 0,message = "Book Id Limit is 10 digit only")
    private Integer bookId;

    @Size(min=4,max=12,message="book name limit is 4 to 12")
    @NotEmpty(message ="book name is empty.")
    @NotBlank(message = "book name is blank")
    private String bookName;

    @Digits(integer = 3, fraction = 0,message = "Book Id Limit is 10 digit only")
    private Integer bookPage;

    @OneToOne(cascade = CascadeType.ALL, mappedBy = "book")
    private Story story;
}
