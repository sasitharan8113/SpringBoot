package demo.bootproject.StringExample.entity;

import lombok.Data;

@Data
public class JsonFormat {
    private String name;
    private int age;


    public JsonFormat(String name, int age) {
        this.name=name;
        this.age=age;
    }

}
