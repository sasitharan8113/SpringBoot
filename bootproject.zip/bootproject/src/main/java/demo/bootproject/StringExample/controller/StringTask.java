package demo.bootproject.StringExample.controller;


import demo.bootproject.StringExample.entity.JsonFormat;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
//root path
@RequestMapping("/stringMethod")
public class StringTask {
    @Autowired
    private Environment env;


    //Get Method = http://localhost:8081/stringMethod/api
    @GetMapping("/api")
    public String input(){
        return "hello world";
    }


    //Get Method = http://localhost:8081/stringMethod/getDetails
    @GetMapping("/getDetails")
    public JsonFormat dataBean(){
        return new JsonFormat("sasi", 12);
    }

    //Application properties.
    //Get Method=http://localhost:8081/stringMethod/name
    @Value("${name}")
    private String name;

    @GetMapping(value="/name")
    public String name() {
        return name;
    }

    //Application properties environment
    //Get Method=http://localhost:8081/stringMethod/env
    @GetMapping("/env")
    public String name1(){
        return env.getProperty("name1");
    }


    //Json Object
    //GetMethod=http://localhost:8081/stringMethod/getJson
    @GetMapping("/getJson")
    public String display() throws JSONException {
        JSONObject obj=new JSONObject();
        obj.put("name","mathan");
        obj.put("age",24);
        return obj.toString();
    }

    //ResponseEntity
    //Get Method=http://localhost:8081/stringMethod/entry
    @GetMapping("/entry")
    public ResponseEntity<?> hello() {
        return ResponseEntity.ok("Hello");
    }

}
