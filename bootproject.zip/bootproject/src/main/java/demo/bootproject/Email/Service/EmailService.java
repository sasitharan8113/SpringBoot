package demo.bootproject.Email.Service;

import demo.bootproject.Email.Entity.EmailEntity;
import jakarta.mail.internet.MimeMessage;
import net.minidev.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import java.io.File;

@Service
public class EmailService {

    @Autowired
    JavaMailSender javaMailSender;

    @Autowired
    private Environment env;

    public ResponseEntity<?> sendMessage(EmailEntity data)throws Exception{
        MimeMessage message=javaMailSender.createMimeMessage();
        MimeMessageHelper helper=new MimeMessageHelper(message,true);

        //Email From
        helper.setFrom(env.getProperty("username"));

        //Email To
        helper.setTo(data.getToEmail());

        //Mail Body
        helper.setText(data.getBody());

        //Mail subject
        helper.setSubject(data.getSubject());

        //Attachment
        FileSystemResource file = new FileSystemResource(new File(data.getAttachment()));
        helper.addAttachment(file.getFilename(), file);

        //cc
        helper.setCc(data.getCc());

        //bcc
        helper.setBcc(data.getBcc());

        javaMailSender.send(message);
        JSONObject obj=new JSONObject();
        obj.put("message","Email sent is successfully");
        return new ResponseEntity<>(obj, HttpStatus.OK);
    }

}
