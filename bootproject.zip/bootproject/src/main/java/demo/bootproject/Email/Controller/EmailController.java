package demo.bootproject.Email.Controller;

import demo.bootproject.Email.Entity.EmailEntity;
import demo.bootproject.Email.Service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.mail.MessagingException;

@RestController
@RequestMapping("/mail")
public class EmailController {

    @Autowired
    EmailService senderService;

    @PostMapping("/sentMail")
    public ResponseEntity<?> itEmail(@RequestBody EmailEntity data) throws Exception {
           return senderService.sendMessage(data);
    }
}
