package demo.bootproject.Email.Entity;

import lombok.Data;

@Data
public class EmailEntity {
    private String[] toEmail;
    private String body;
    private String subject;
    private String attachment;
    private String[] cc;
    private String[] bcc;
}
