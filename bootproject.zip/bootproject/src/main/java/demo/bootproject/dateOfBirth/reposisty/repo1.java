package demo.bootproject.dateOfBirth.reposisty;

import demo.bootproject.dateOfBirth.entity.DataMethod;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import java.sql.Date;
import java.util.List;

@Repository
public interface repo1 extends JpaRepository<DataMethod,Integer> {
    @Query(value = "SELECT t FROM DataMethod t order by :detailsName ASC")
    List<DataMethod> getAllDates(@Param("detailsName")String detailsName);

//    @Query(value = "SELECT t FROM DataMethod t order by :detailsName DESC")
//    List<DataMethod> getAllDates1(@Param("detailsName1")String detailsName);

    @Query(value="select m from DataMethod m where dob between :startDate and :endDate")
    List<DataMethod>getAllDates2(@Param("startDate")Date startDate, @Param("endDate")Date endDate);

}
