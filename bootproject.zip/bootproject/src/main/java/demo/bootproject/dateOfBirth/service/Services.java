package demo.bootproject.dateOfBirth.service;


import demo.bootproject.dateOfBirth.entity.DataMethod;
import demo.bootproject.dateOfBirth.reposisty.repo1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Service
public class Services {
    @Autowired
    repo1 jpa;

    public DataMethod addValue(DataMethod getData){
        return this.jpa.save(getData);
    }

    public List<DataMethod> getAllData(){
        return this.jpa.findAll();
    }

    public List<DataMethod> getAllDates(String detailsName){
        return this.jpa.getAllDates(detailsName);
    }

//    public List<DataMethod> getAllDates1(String detailsName1){
//        return this.jpa.getAllDates1(detailsName1);
//    }

    public List<DataMethod>getAllDates2(Date startDate,Date endDate){
        return this.jpa.getAllDates2(startDate,endDate);
    }

    public List<DataMethod> getAllDetails(Integer pageNo, Integer pageSize)
    {
        Pageable paging = PageRequest.of(pageNo, pageSize);

        Page<DataMethod> pagedResult = jpa.findAll(paging);

        if(pagedResult.hasContent()) {
            return pagedResult.getContent();
        } else {
            return new ArrayList<DataMethod>();
        }
    }

}
