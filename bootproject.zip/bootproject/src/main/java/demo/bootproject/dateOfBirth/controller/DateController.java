package demo.bootproject.dateOfBirth.controller;

import demo.bootproject.dateOfBirth.entity.DataMethod;
import demo.bootproject.dateOfBirth.service.Services;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.util.List;

@RestController
@RequestMapping("/date")
public class DateController {
    @Autowired
    Services personDetails;

    //Post Method=http://localhost:8080/date/insertValue
    @PostMapping("/insertValue")
    public DataMethod personalMember(@RequestBody DataMethod myData) {
        return personDetails.addValue(myData);
    }

    //Get Method=http://localhost:8080/date/getAll
    @GetMapping("/getAll")
    public List<DataMethod> studentDetails(){
        return this.personDetails.getAllData();
    }

    //Get Method=http://localhost:8080/date/dateAscending
    @GetMapping("/dateAscending")
    public List<DataMethod>getDates(String detailsName){
        return this.personDetails.getAllDates(detailsName);
    }

    //Get Method=http://localhost:8080/date/dateDescending
//    @GetMapping("/dateDescending")
//    public List<DataMethod>getDates1(String detailsName){
//        return this.personDetails.getAllDates1(detailsName);
//    }

    //Get Method=http://localhost:8080/date/dateFunction
    @GetMapping("/dateFunction")
    public List<DataMethod> getDates2(Date startDate,Date endDate){
        return this.personDetails.getAllDates2(startDate,endDate);
    }

    //Pagination Method
    //Get Method=http://localhost:8080/date/page?pageSize=1&pageNo=0
    @GetMapping("/page")
    public ResponseEntity<List<DataMethod>> getAllEmployees(
            @RequestParam(defaultValue = "0") Integer pageNo,
            @RequestParam(defaultValue = "5") Integer pageSize)
    {
        List<DataMethod> list = personDetails.getAllDetails(pageNo, pageSize);

        return new ResponseEntity<List<DataMethod>>(list, new HttpHeaders(), HttpStatus.OK);
    }
}
