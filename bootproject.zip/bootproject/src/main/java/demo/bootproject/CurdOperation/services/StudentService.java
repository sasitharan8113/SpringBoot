package demo.bootproject.CurdOperation.services;

import demo.bootproject.CurdOperation.entity.data;
import demo.bootproject.CurdOperation.repository.repo;
import net.minidev.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class StudentService {
    @Autowired
    repo jpa;

    public String addValue(data getData){
        this.jpa.save(getData);
        JSONObject obj=new JSONObject();
        obj.put("Status:","Insert the data successfully");
        return obj.toString();
    }

    public List<data>getAllData(){
        return this.jpa.findAll();
    }

    public Optional<data> getId(Integer id){
        return this.jpa.findById(id);
    }

    public Optional<data> getId1(Integer id){
        return this.jpa.findById(id);
    }

    public String updateRecord(Integer id,data change){
        data oldRecord = this.jpa.findById(id).orElseThrow();
        oldRecord.setName(change.getName());
        oldRecord.setPercentage(change.getPercentage());
        oldRecord.setDob(change.getDob());
        oldRecord.setPhoneNumber(change.getPhoneNumber());
        this.jpa.save(oldRecord);
        JSONObject obj=new JSONObject();
        obj.put("Status:","Update the data successfully");
        return obj.toString();
    }

    public String deleteRecord(Integer id){
        this.jpa.deleteById(id);
        JSONObject obj=new JSONObject();
        obj.put("Status:","Delete the data successfully");
        return obj.toString();
    }

    public List<data>findAllDetails1(){
        return jpa.findAllDetails1();
    }

    public List<data>findSpecificDetails(){
        return jpa.findSpecificDetails();
    }

    public List<data>findAllDetails2(){
        return jpa.findAllDetails2();
    }

    public List<data>findAllDetails3(){
        return jpa.findAllDetails3();
    }

    public List<data>findAllInformation(){
        return jpa.findAllInformation();
    }

}
