package demo.bootproject.CurdOperation.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Entity
@Data
@Table(name="studentInformation")
public class data {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;

    private Double percentage;

    @JsonFormat(pattern = "dd/MM/yyyy")
    private Date dob;

    private Long phoneNumber;

}
