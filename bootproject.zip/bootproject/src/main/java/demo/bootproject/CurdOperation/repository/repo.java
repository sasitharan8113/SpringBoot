package demo.bootproject.CurdOperation.repository;

import demo.bootproject.CurdOperation.entity.data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface repo extends JpaRepository<data,Integer>{

    //native query
    @Query(value="SELECT *FROM student_information",nativeQuery = true)
    List<data>findAllDetails1();

    @Query(value="select * from student_information where id = ?",nativeQuery = true)
    List<data>findSpecificDetails();



    //Hibernate query
    @Query(value = "SELECT e FROM data e")
    List<data>findAllDetails2();

    @Query(value = "select e from data e where id =: id")
    List<data>findAllDetails3();

    //Jpa query
    @Query(name= "query")
    List<data>findAllInformation();

}
