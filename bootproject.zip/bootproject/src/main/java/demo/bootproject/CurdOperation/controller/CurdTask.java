package demo.bootproject.CurdOperation.controller;

import demo.bootproject.CurdOperation.entity.data;
import demo.bootproject.CurdOperation.services.StudentService;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/curd")
public class CurdTask {

    @Autowired
    StudentService studentPersonDetails;

    //Post Request=http://localhost:8080/curd/post
    @PostMapping("/post")
    public String student(@RequestBody data myData) {
        return studentPersonDetails.addValue(myData);
    }


    //Get Request=http://localhost:8080/curd/getAll
    @GetMapping("/getAll")
    public List<data> studentDetails(){
        return this.studentPersonDetails.getAllData();
    }


    //Get Id Request=http://localhost:8080/curd/getParticular/{id}
    @GetMapping("/getParticular/{id}")
    public Optional<data> studentId(@PathVariable (value="id")Integer identity){
        return this.studentPersonDetails.getId(identity);
    }


    //Get Request=http://localhost:8080/curd/getParticular?id={id}
    @GetMapping("/getParticular")
    public Optional<data> studentId1(@RequestParam (value="id")Integer identity){
        return this.studentPersonDetails.getId1(identity);
    }


    //Put Request=http://localhost:8080/curd/updateData/{id}
    @PutMapping("/updateData/{id}")
    public String updateData(@PathVariable(value="id")Integer id, @RequestBody data change){
        return this.studentPersonDetails.updateRecord(id,change);
    }


    //Delete Request=http://localhost:8080/curd/deletedData/{id}
    @DeleteMapping("/deletedData/{id}")
    public String deletedData(@PathVariable(value="id")Integer id) throws JSONException {
        return this.studentPersonDetails.deleteRecord(id);
    }

    //Native query.
    //Get Method=http://localhost:8080/curd/native
    @GetMapping("/native")
    public List<data>nativeQuery(){
        return studentPersonDetails.findAllDetails1();
    }

    //Get Method=http://localhost:8080/curd/nativeDetails
    @GetMapping("/nativeDetails")
    public List<data>specificQuery(){
        return studentPersonDetails.findSpecificDetails();
    }

    //HQL
    //Get Method=http://localhost:8080/curd/hql
    @GetMapping("/hql")
    public List<data>hibernate(){
        return studentPersonDetails.findAllDetails2();
    }

    //Get Method=http://localhost:8080/curd/specificHql
    @GetMapping("/specificHql")
    public List<data>hibernate1(){
        return studentPersonDetails.findAllDetails3();
    }

    //Get Method=http://localhost:8080/curd/getJpa
    @GetMapping("/getJpa")
    public List<data>jpaQuery1(){
        return studentPersonDetails.findAllInformation();
    }

}
