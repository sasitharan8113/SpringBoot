package demo.bootproject.FileUpload.Controller;

import demo.bootproject.FileUpload.Entity.UploadFileEntity;
import demo.bootproject.FileUpload.Service.UploadFileService;
import demo.bootproject.FileUpload.Util.insertData;
import demo.bootproject.dateOfBirth.entity.DataMethod;
import net.minidev.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;


@RestController
@RequestMapping("/upload")
public class UploadController {

    @Autowired
    UploadFileService service;

    @PostMapping("/fileUploadDetails")
    public ResponseEntity<?> uploadFile(@RequestBody MultipartFile importFile) throws Exception {
        this.service.uploadFileSave(importFile);
        JSONObject obj=new JSONObject();
        obj.put("message","Upload file is completed.");
        return new ResponseEntity<>(obj,HttpStatus.OK);
    }

    @GetMapping("/getAll")
    public List<UploadFileEntity> studentDetails(){
        return this.service.getAllData();
    }

}
