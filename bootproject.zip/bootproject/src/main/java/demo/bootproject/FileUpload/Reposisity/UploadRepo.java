package demo.bootproject.FileUpload.Reposisity;

import demo.bootproject.FileUpload.Entity.UploadFileEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UploadRepo extends JpaRepository<UploadFileEntity, Long> {
}
