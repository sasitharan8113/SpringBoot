package demo.bootproject.FileUpload.Service;

import demo.bootproject.FileUpload.Entity.UploadFileEntity;
import demo.bootproject.FileUpload.Reposisity.UploadRepo;
import demo.bootproject.FileUpload.Util.insertData;
import demo.bootproject.dateOfBirth.entity.DataMethod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.util.List;

@Service
public class UploadFileService {

    @Autowired
    UploadRepo fileReposisty;

    public void uploadFileSave(MultipartFile importFile) throws Exception {
        List<UploadFileEntity> uploadFile = insertData.excelToTutorials(importFile.getInputStream());
        this.fileReposisty.saveAll(uploadFile);
    }

    public List<UploadFileEntity> getAllData(){
        return this.fileReposisty.findAll();
    }
}
