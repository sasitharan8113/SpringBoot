package demo.bootproject.FileUpload.Entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

import java.sql.Time;
import java.util.Date;
import java.util.Timer;

@Data
@Entity
@Table(name = "uploadFile")
public class UploadFileEntity {

    @Id
    private Long RegNo;

    private String Name;

    private Integer Age;

    @JsonFormat(pattern="dd/mm/yyyy")
    private Date DOB;

    private Double Mark;


}
