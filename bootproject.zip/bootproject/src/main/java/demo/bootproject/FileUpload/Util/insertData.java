package demo.bootproject.FileUpload.Util;

import demo.bootproject.FileUpload.Entity.UploadFileEntity;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class insertData {

    public static List<UploadFileEntity> excelToTutorials(InputStream details) {
        try {
            HSSFWorkbook workbook = new HSSFWorkbook(details);

            HSSFSheet sheet = workbook.getSheet("EmployeeDetails");
            Iterator<Row> rows = sheet.iterator();

            List<UploadFileEntity> tutorials = new ArrayList<>();

            int rowNumber = 0;
            while (rows.hasNext()) {
                Row currentRow = rows.next();

                if (rowNumber == 0) {
                    rowNumber++;
                    continue;
                }

                Iterator<Cell> cellsInRow = currentRow.iterator();

                UploadFileEntity tutorial = new UploadFileEntity();

                int cellIdx = 0;
                while (cellsInRow.hasNext()) {
                    Cell currentCell = cellsInRow.next();

                    switch (cellIdx) {
                        case 0:
                            tutorial.setRegNo((long) currentCell.getNumericCellValue());
                            break;

                        case 1:
                            tutorial.setName(currentCell.getStringCellValue());
                            break;

                        case 2:
                            tutorial.setAge((int) currentCell.getNumericCellValue());
                            break;

                        case 3:
                            tutorial.setDOB((currentCell.getDateCellValue()));
                            break;

                        case 4:
                            tutorial.setMark(Double.valueOf(currentCell.getNumericCellValue()));
                            break;

                        default:
                            break;
                    }

                    cellIdx++;
                }

                tutorials.add(tutorial);
            }

            workbook.close();

            return tutorials;
        } catch (IOException e) {
            throw new RuntimeException("fail to parse Excel file: " + e.getMessage());
        }
    }
}
