package demo.bootproject.EmailSchedule.Controller;

import jakarta.mail.internet.MimeMessage;
import net.minidev.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;

@RestController
public class Schedule {

    @Autowired
    JavaMailSender javaMailSender;

    @Autowired
    private Environment env;

//    @Scheduled(cron = "*/4 * * * * *")
    public ResponseEntity<?> sendMessage()throws Exception{
        MimeMessage message=javaMailSender.createMimeMessage();
        MimeMessageHelper helper=new MimeMessageHelper(message,true);

        //Email From
        helper.setFrom(env.getProperty("username"));

        //Email To
        helper.setTo(env.getProperty("emailId"));

        //Mail Body
        helper.setText(env.getProperty("body"));

        //Mail subject
        helper.setSubject(env.getProperty("subject"));

        //Attachment
        FileSystemResource file = new FileSystemResource(new File(env.getProperty("attachment")));
        helper.addAttachment(file.getFilename(), file);

        javaMailSender.send(message);
        JSONObject obj=new JSONObject();
        obj.put("message","Email sent is successfully");
        return new ResponseEntity<>(obj, HttpStatus.OK);
    }
}
